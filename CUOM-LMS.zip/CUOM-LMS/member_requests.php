<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

require_role(['Administrator', 'Librarian']);

$pdo = get_db_connection();
$stmt = $pdo->prepare('SELECT u.*, br.name AS branch_name FROM users u LEFT JOIN branches br ON u.branch_id = br.id WHERE u.role_id = (SELECT id FROM roles WHERE name = :memberRole) AND u.status = 0 ORDER BY u.created_at DESC');
$stmt->execute([':memberRole' => 'Member']);
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Member Requests - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Pending Member Approvals</h1>
            <p>Review new registration requests and approve or reject members.</p>
            <?php render_flash_messages(); ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Institution ID</th>
                        <th>Email</th>
                        <th>Branch</th>
                        <th>Submitted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['institution_id']); ?></td>
                            <td><?php echo htmlspecialchars($request['email']); ?></td>
                            <td><?php echo htmlspecialchars($request['branch_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($request['created_at']); ?></td>
                            <td>
                                <form method="post" action="member_action.php" style="display:inline-block; margin-right:0.5rem;">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $request['id']; ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button type="submit" class="dashboard-link">Approve</button>
                                </form>
                                <form method="post" action="member_action.php" style="display:inline-block;">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $request['id']; ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" class="logout-button">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
