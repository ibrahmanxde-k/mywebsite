<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

require_role(['Administrator', 'Librarian']);
$pdo = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        header('Location: payments.php');
        exit;
    }

    $fineId = (int) ($_POST['fine_id'] ?? 0);
    $amount = (float) ($_POST['amount'] ?? 0);
    $paymentMethod = trim($_POST['payment_method'] ?? 'Cash');

    if (!$fineId || $amount <= 0) {
        set_flash('Invalid payment details.', 'error');
        header('Location: payments.php');
        exit;
    }

    $stmt = $pdo->prepare('SELECT f.*, u.id AS user_id, u.full_name, u.email FROM fines f JOIN borrow_transactions bt ON f.transaction_id = bt.id JOIN users u ON bt.user_id = u.id WHERE f.id = :id LIMIT 1');
    $stmt->execute([':id' => $fineId]);
    $fine = $stmt->fetch();

    if (!$fine || $fine['status'] !== 'unpaid') {
        set_flash('Fine not found or already settled.', 'error');
        header('Location: payments.php');
        exit;
    }

    $paidAmount = $fine['paid_amount'] + $amount;
    $isPaid = $paidAmount >= $fine['amount'];
    $status = $isPaid ? 'paid' : 'unpaid';

    $pdo->beginTransaction();
    $stmt = $pdo->prepare('UPDATE fines SET paid_amount = :paid_amount, status = :status WHERE id = :id');
    $stmt->execute([':paid_amount' => $paidAmount, ':status' => $status, ':id' => $fineId]);

    $stmt = $pdo->prepare('INSERT INTO payments (user_id, fine_id, amount, payment_method) VALUES (:user_id, :fine_id, :amount, :payment_method)');
    $stmt->execute([':user_id' => $fine['user_id'], ':fine_id' => $fineId, ':amount' => $amount, ':payment_method' => $paymentMethod]);
    $pdo->commit();

    record_audit_log($_SESSION['user_id'], 'fine_payment', 'Fine ID ' . $fineId . ' paid ' . $amount);
    send_user_notification($fine['user_id'], 'fine_payment', 'Fine Payment Received', 'A payment of TZS ' . number_format($amount, 2) . ' was received. Thank you.');

    set_flash('Payment recorded successfully.', 'success');
    header('Location: payments.php');
    exit;
}

$stmt = $pdo->query('SELECT f.*, bt.due_date, bt.fine_amount, b.title AS book_title, u.full_name AS member_name FROM fines f JOIN borrow_transactions bt ON f.transaction_id = bt.id JOIN books b ON bt.book_id = b.id JOIN users u ON bt.user_id = u.id ORDER BY f.created_at DESC');
$fines = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Fine Payments</h1>
            <p>Record fine payments and close overdue balances.</p>
            <?php render_flash_messages(); ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Book</th>
                        <th>Due Date</th>
                        <th>Fine</th>
                        <th>Paid</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($fines as $fine): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($fine['member_name']); ?></td>
                            <td><?php echo htmlspecialchars($fine['book_title']); ?></td>
                            <td><?php echo htmlspecialchars($fine['due_date']); ?></td>
                            <td><?php echo number_format($fine['amount'], 2); ?></td>
                            <td><?php echo number_format($fine['paid_amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($fine['status']); ?></td>
                            <td>
                                <?php if ($fine['status'] === 'unpaid'): ?>
                                    <form method="post" action="payments.php" class="inline-form">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                                        <input type="hidden" name="fine_id" value="<?php echo $fine['id']; ?>">
                                        <input type="number" name="amount" step="0.01" min="0.01" placeholder="Amount" required>
                                        <select name="payment_method">
                                            <option value="Cash">Cash</option>
                                            <option value="Mobile Money">Mobile Money</option>
                                        </select>
                                        <button type="submit">Pay</button>
                                    </form>
                                <?php else: ?>
                                    <span>Settled</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
