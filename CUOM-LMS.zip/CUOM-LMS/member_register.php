<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

$memberRoleId = get_role_id_by_name('Member');
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        redirect_to('member_register.php');
    }

    $institution_id = trim($_POST['institution_id'] ?? '');
    $registration_number = trim($_POST['registration_number'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($institution_id === '' || $full_name === '' || $email === '') {
        set_flash('Institution ID, full name, and email are required.', 'error');
        redirect_to('member_register.php');
    }

    $password = password_hash('Pending123!', PASSWORD_DEFAULT);
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('INSERT INTO users (institution_id, registration_number, email, password_hash, role_id, full_name, status) VALUES (:institution_id, :registration_number, :email, :password_hash, :role_id, :full_name, 0)');
    $stmt->execute([
        ':institution_id' => $institution_id,
        ':registration_number' => $registration_number,
        ':email' => $email,
        ':password_hash' => $password,
        ':role_id' => $memberRoleId,
        ':full_name' => $full_name,
    ]);

    set_flash('Registration request submitted. Await administrator approval.', 'success');
    redirect_to('member_register.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Registration - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <h1>Member Registration</h1>
            <p>Submit your details for approval before accessing the library portal.</p>
            <?php render_flash_messages(); ?>
            <form method="post" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <label for="institution_id">Institution ID</label>
                <input type="text" id="institution_id" name="institution_id" value="<?php echo old_value('institution_id'); ?>" required>

                <label for="registration_number">Registration Number</label>
                <input type="text" id="registration_number" name="registration_number" value="<?php echo old_value('registration_number'); ?>">

                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" value="<?php echo old_value('full_name'); ?>" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo old_value('email'); ?>" required>

                <button type="submit">Submit Registration</button>
            </form>
            <p><a href="index.php">Back to login</a></p>
        </div>
    </div>
</body>
</html>
