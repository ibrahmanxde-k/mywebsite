<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

require_role(['Administrator', 'Librarian']);
$branches = get_active_branches();
$categories = get_categories();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        redirect_to('books_add.php');
    }

    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $publisher = trim($_POST['publisher'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $edition = trim($_POST['edition'] ?? '');
    $category_id = $_POST['category_id'] ?? null;
    $branch_id = $_POST['branch_id'] ?? null;
    $quantity = max(1, (int) ($_POST['total_quantity'] ?? 1));

    if ($title === '' || $author === '') {
        set_flash('Book title and author are required.', 'error');
        redirect_to('books_add.php');
    }

    $pdo = get_db_connection();
    $stmt = $pdo->prepare('INSERT INTO books (title, author, publisher, isbn, edition, category_id, branch_id, total_quantity, available_quantity, status) VALUES (:title, :author, :publisher, :isbn, :edition, :category_id, :branch_id, :quantity, :quantity, 1)');
    $stmt->execute([
        ':title' => $title,
        ':author' => $author,
        ':publisher' => $publisher,
        ':isbn' => $isbn,
        ':edition' => $edition,
        ':category_id' => $category_id ?: null,
        ':branch_id' => $branch_id ?: null,
        ':quantity' => $quantity,
    ]);

    $bookId = $pdo->lastInsertId();
    $qrCode = generate_book_qr_code($bookId);
    $stmt = $pdo->prepare('UPDATE books SET qr_code = :qr_code WHERE id = :id');
    $stmt->execute([':qr_code' => $qrCode, ':id' => $bookId]);

    set_flash('Book added successfully. QR label generated.');
    redirect_to('books.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Add New Book</h1>
            <?php render_flash_messages(); ?>
            <form method="post" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <label for="title">Title</label>
                <input type="text" id="title" name="title" value="<?php echo old_value('title'); ?>" required>

                <label for="author">Author</label>
                <input type="text" id="author" name="author" value="<?php echo old_value('author'); ?>" required>

                <label for="publisher">Publisher</label>
                <input type="text" id="publisher" name="publisher" value="<?php echo old_value('publisher'); ?>">

                <label for="isbn">ISBN</label>
                <input type="text" id="isbn" name="isbn" value="<?php echo old_value('isbn'); ?>">

                <label for="edition">Edition</label>
                <input type="text" id="edition" name="edition" value="<?php echo old_value('edition'); ?>">

                <label for="category_id">Category</label>
                <select id="category_id" name="category_id">
                    <option value="">General</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="branch_id">Branch</label>
                <select id="branch_id" name="branch_id">
                    <option value="">Unassigned</option>
                    <?php foreach ($branches as $branch): ?>
                        <option value="<?php echo $branch['id']; ?>"><?php echo htmlspecialchars($branch['name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="total_quantity">Total Quantity</label>
                <input type="number" id="total_quantity" name="total_quantity" min="1" value="<?php echo old_value('total_quantity', 1); ?>" required>

                <button type="submit">Save Book</button>
            </form>
            <p><a href="books.php">Back to book list</a></p>
        </div>
    </div>
</body>
</html>
