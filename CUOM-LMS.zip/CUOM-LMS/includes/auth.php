<?php
require_once __DIR__ . '/db.php';

function get_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function is_logged_in() {
    return !empty($_SESSION['user_id']);
}

function login_user($identity, $password) {
    if (!empty($_SESSION['failed_login_attempts']) && $_SESSION['failed_login_attempts'] >= FAILED_LOGIN_LIMIT) {
        return false;
    }

    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT u.id, u.password_hash, r.name AS role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.institution_id = :identity OR u.registration_number = :identity LIMIT 1');
    $stmt->execute([':identity' => $identity]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role_name'];
        $_SESSION['last_activity'] = time();
        $_SESSION['failed_login_attempts'] = 0;
        return true;
    }

    $_SESSION['failed_login_attempts'] = ($_SESSION['failed_login_attempts'] ?? 0) + 1;
    return false;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: index.php');
        exit;
    }
}

function user_has_role($expectedRoles) {
    if (!is_logged_in()) {
        return false;
    }
    $currentRole = $_SESSION['role'] ?? '';
    if (is_array($expectedRoles)) {
        return in_array($currentRole, $expectedRoles, true);
    }
    return $currentRole === $expectedRoles;
}

function require_role($expectedRoles) {
    if (!user_has_role($expectedRoles)) {
        header('HTTP/1.1 403 Forbidden');
        echo 'Access denied';
        exit;
    }
}

function get_current_user() {
    if (!is_logged_in()) {
        return null;
    }
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = :id');
    $stmt->execute([':id' => $_SESSION['user_id']]);
    return $stmt->fetch();
}
