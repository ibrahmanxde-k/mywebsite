<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

function set_flash($message, $type = 'success') {
    $_SESSION['flash'][] = ['message' => $message, 'type' => $type];
}

function get_flash_messages() {
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function redirect_to($url) {
    header('Location: ' . $url);
    exit;
}

function old_value($field, $default = '') {
    return htmlspecialchars($_POST[$field] ?? $default);
}

function get_active_branches() {
    $pdo = get_db_connection();
    $stmt = $pdo->query('SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name');
    return $stmt->fetchAll();
}

function get_categories() {
    $pdo = get_db_connection();
    $stmt = $pdo->query('SELECT id, name FROM categories ORDER BY name');
    return $stmt->fetchAll();
}

function get_notifications_for_user($userId, $limit = 10) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :limit');
    $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function get_user_due_borrowings($userId) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT bt.*, b.title FROM borrow_transactions bt JOIN books b ON bt.book_id = b.id WHERE bt.user_id = :user_id AND bt.returned_at IS NULL ORDER BY bt.due_date ASC');
    $stmt->execute([':user_id' => $userId]);
    return $stmt->fetchAll();
}

function get_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return !empty($token) && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function get_role_id_by_name($name) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT id FROM roles WHERE name = :name LIMIT 1');
    $stmt->execute([':name' => $name]);
    return $stmt->fetchColumn();
}

function get_active_members() {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT id, full_name, institution_id FROM users WHERE role_id = (SELECT id FROM roles WHERE name = :memberRole) AND status = 1 ORDER BY full_name');
    $stmt->execute([':memberRole' => 'Member']);
    return $stmt->fetchAll();
}

function get_available_books() {
    $pdo = get_db_connection();
    $stmt = $pdo->query('SELECT b.id, b.title, b.available_quantity, br.name AS branch_name FROM books b LEFT JOIN branches br ON b.branch_id = br.id WHERE b.available_quantity > 0 AND b.status = 1 ORDER BY b.title');
    return $stmt->fetchAll();
}

function calculate_fine_amount($dueDate, $returnDate, $ratePerDay = 200) {
    $due = new DateTime($dueDate);
    $return = new DateTime($returnDate);
    if ($return <= $due) {
        return 0.00;
    }
    $daysPast = (int) $due->diff($return)->format('%a');
    return round($daysPast * $ratePerDay, 2);
}

function generate_book_qr_code($bookId) {
    return 'CUOM-BK-' . $bookId . '-' . strtoupper(bin2hex(random_bytes(4)));
}

function get_book_by_qr_code($qrCode) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT * FROM books WHERE qr_code = :qr_code LIMIT 1');
    $stmt->execute([':qr_code' => $qrCode]);
    return $stmt->fetch();
}

function record_audit_log($userId, $action, $details = null) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (:user_id, :action, :details, :ip_address)');
    $stmt->execute([
        ':user_id' => $userId,
        ':action' => $action,
        ':details' => $details,
        ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    ]);
}

function render_flash_messages() {
    $messages = get_flash_messages();
    if (empty($messages)) {
        return;
    }
    foreach ($messages as $flash) {
        $class = $flash['type'] === 'error' ? 'alert' : 'alert-success';
        echo '<div class="' . $class . '">' . htmlspecialchars($flash['message']) . '</div>';
    }
}
