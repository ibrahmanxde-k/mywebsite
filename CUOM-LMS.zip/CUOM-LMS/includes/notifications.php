<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/mail.php';

function create_notification($user_id, $type, $subject, $message) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('INSERT INTO notifications (user_id, type, subject, message, is_read) VALUES (:user_id, :type, :subject, :message, 0)');
    $stmt->execute([
        ':user_id' => $user_id,
        ':type' => $type,
        ':subject' => $subject,
        ':message' => $message,
    ]);
}

function send_user_notification($user_id, $type, $subject, $message) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT email FROM users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $user_id]);
    $user = $stmt->fetch();
    if (!$user) {
        return false;
    }
    create_notification($user_id, $type, $subject, $message);
    return send_email($user['email'], $subject, $message);
}
