# CUOM Library Management System

A Diploma Final Year Project (Mradi wa Diploma) for Catholic University of Mbeya (CUOM).

## Overview

This is a PHP and MySQL based Library Management System scaffold for CUOM. It includes core modules for authentication, book management, member management, borrowing/return, fines, notifications, and multi-branch support.

## Getting Started

1. Install a local web server stack supporting PHP 8 and MySQL (e.g. XAMPP, WAMP).
2. Copy the project folder into your web server's document root, or use the built-in PHP server.
3. Create a MySQL database and import `init.sql`.
4. Update database credentials in `config.php`.
5. Open the application in your browser.

### Run with PHP Built-in Server

From the project root, run:

```bash
php -S localhost:8000 -t .
```

Then open `http://localhost:8000` in your browser.

## Project Structure

- `index.php` - main entry and login page
- `config.php` - database and application config
- `includes/db.php` - database connection helper
- `includes/auth.php` - authentication and session management
- `init.sql` - database schema and seeded admin user
- `assets/css/style.css` - basic styles
- `assets/js/scripts.js` - client-side behaviors

## Available Pages

- `index.php` - login page
- `dashboard.php` - role-based portal entry
- `branches.php` - branch management (Admin only)
- `branches_add.php` - add library branch (Admin only)
- `books.php` - book inventory listing (Admin/Librarian)
- `books_add.php` - add library book (Admin/Librarian)
- `members.php` - member directory (Admin/Librarian)
- `members_add.php` - create new member account (Admin/Librarian)
- `member_requests.php` - view pending member approvals (Admin/Librarian)
- `borrow_book.php` - create new borrow transaction (Admin/Librarian)
- `return_book.php` - process book returns and calculate fines (Admin/Librarian)
- `payments.php` - record fine payments and settle overdue balances (Admin/Librarian)
- `send_reminders.php` - send due-date and overdue notifications (Admin/Librarian)
- `scheduled_reminders.php` - CLI reminder script for automated task scheduling
- `reports.php` - analytics and summary reports (Admin/Librarian)
- `opac.php` - public catalog and book search
- `borrowings.php` - borrow/return records (Admin/Librarian)
- `member_portal.php` - member dashboard (Member only)
- `member_register.php` - self-registration request form
- `forgot_password.php` - password reset request placeholder
- `logout.php` - end user session

## Notes

- Seeded admin login: `CUOMADMIN001` / `Admin@123`
- The database schema now includes books, categories, borrow transactions, fines, payments, notifications, and audit logs.
- Books now generate a QR code label on creation, visible in the book inventory list.
- Use `php scheduled_reminders.php` to send due-date and overdue reminders automatically from a scheduler.
- For full deployment, configure a task scheduler or cron job and enable email sending for notifications.
