<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';

$search = trim($_GET['q'] ?? '');
$params = [];
$sql = 'SELECT b.*, c.name AS category_name, br.name AS branch_name FROM books b LEFT JOIN categories c ON b.category_id = c.id LEFT JOIN branches br ON b.branch_id = br.id WHERE b.status = 1';

if ($search !== '') {
    $sql .= ' AND (b.title LIKE :search OR b.author LIKE :search OR b.isbn LIKE :search OR c.name LIKE :search)';
    $params[':search'] = '%' . $search . '%';
}
$sql .= ' ORDER BY b.title';

$pdo = get_db_connection();
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CUOM OPAC</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Online Public Access Catalog</h1>
            <p>Search the CUOM library catalog by title, author, ISBN, or category.</p>
            <form method="get" action="opac.php">
                <input type="text" name="q" placeholder="Search books..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
            </form>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Branch</th>
                        <th>Available</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($books)): ?>
                        <tr>
                            <td colspan="5">No matching books found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($book['title']); ?></td>
                                <td><?php echo htmlspecialchars($book['author']); ?></td>
                                <td><?php echo htmlspecialchars($book['category_name'] ?? 'General'); ?></td>
                                <td><?php echo htmlspecialchars($book['branch_name'] ?? 'Unassigned'); ?></td>
                                <td><?php echo (int) $book['available_quantity']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
