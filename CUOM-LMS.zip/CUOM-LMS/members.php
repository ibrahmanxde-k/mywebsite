<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_role(['Administrator', 'Librarian']);

$pdo = get_db_connection();
$stmt = $pdo->prepare('SELECT u.*, br.name AS branch_name FROM users u LEFT JOIN branches br ON u.branch_id = br.id WHERE u.role_id = (SELECT id FROM roles WHERE name = :memberRole) ORDER BY u.full_name');
$stmt->execute([':memberRole' => 'Member']);
$members = $stmt->fetchAll();

function member_status_label($status) {
    if ($status === '0' || $status === 0) {
        return 'Pending';
    }
    return $status ? 'Active' : 'Inactive';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Registered Members</h1>
            <p>View the member directory and registration statuses.</p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Branch</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $member): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($member['institution_id']); ?></td>
                            <td><?php echo htmlspecialchars($member['email']); ?></td>
                            <td><?php echo htmlspecialchars($member['branch_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars(member_status_label($member['status'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
