<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

require_role('Administrator');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        redirect_to('branches_add.php');
    }

    $name = trim($_POST['name'] ?? '');
    $location = trim($_POST['location'] ?? '');

    if ($name === '') {
        set_flash('Branch name is required.', 'error');
        redirect_to('branches_add.php');
    }

    $pdo = get_db_connection();
    $stmt = $pdo->prepare('INSERT INTO branches (name, location, is_active) VALUES (:name, :location, 1)');
    $stmt->execute([':name' => $name, ':location' => $location]);
    set_flash('Branch created successfully.');
    redirect_to('branches.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Branch - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Add New Branch</h1>
            <?php render_flash_messages(); ?>
            <form method="post" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <label for="name">Branch Name</label>
                <input type="text" id="name" name="name" value="<?php echo old_value('name'); ?>" required>

                <label for="location">Location</label>
                <input type="text" id="location" name="location" value="<?php echo old_value('location'); ?>">

                <button type="submit">Create Branch</button>
            </form>
            <p><a href="branches.php">Back to branch list</a></p>
        </div>
    </div>
</body>
</html>
