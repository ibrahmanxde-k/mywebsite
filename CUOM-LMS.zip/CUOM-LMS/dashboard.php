<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';

require_login();
$user = get_current_user();
$role = $user['role_name'] ?? $user['role'] ?? 'Member';
$links = [];

if ($role === 'Administrator') {
    $links = [
        ['title' => 'Manage Branches', 'href' => 'branches.php'],
        ['title' => 'Add Branch', 'href' => 'branches_add.php'],
        ['title' => 'Manage Books', 'href' => 'books.php'],
        ['title' => 'Add Book', 'href' => 'books_add.php'],
        ['title' => 'Manage Members', 'href' => 'members.php'],
        ['title' => 'Add Member', 'href' => 'members_add.php'],
        ['title' => 'Pending Member Requests', 'href' => 'member_requests.php'],
        ['title' => 'Borrowing Records', 'href' => 'borrowings.php'],
        ['title' => 'Borrow Book', 'href' => 'borrow_book.php'],
        ['title' => 'Return Book', 'href' => 'return_book.php'],
        ['title' => 'Fine Payments', 'href' => 'payments.php'],
        ['title' => 'Book QR Labels', 'href' => 'books.php'],
        ['title' => 'Send Reminders', 'href' => 'send_reminders.php'],
        ['title' => 'Reports & Analytics', 'href' => 'reports.php'],
        ['title' => 'Public Catalog', 'href' => 'opac.php'],
    ];
} elseif ($role === 'Librarian') {
    $links = [
        ['title' => 'Manage Books', 'href' => 'books.php'],
        ['title' => 'Add Book', 'href' => 'books_add.php'],
        ['title' => 'Manage Members', 'href' => 'members.php'],
        ['title' => 'Add Member', 'href' => 'members_add.php'],
        ['title' => 'Pending Member Requests', 'href' => 'member_requests.php'],
        ['title' => 'Borrowing Records', 'href' => 'borrowings.php'],
        ['title' => 'Borrow Book', 'href' => 'borrow_book.php'],
        ['title' => 'Return Book', 'href' => 'return_book.php'],
        ['title' => 'Fine Payments', 'href' => 'payments.php'],
        ['title' => 'Book QR Labels', 'href' => 'books.php'],
        ['title' => 'Send Reminders', 'href' => 'send_reminders.php'],
        ['title' => 'Reports & Analytics', 'href' => 'reports.php'],
        ['title' => 'Public Catalog', 'href' => 'opac.php'],
    ];
} else {
    $links = [
        ['title' => 'Member Portal', 'href' => 'member_portal.php'],
        ['title' => 'Public Catalog', 'href' => 'opac.php'],
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Welcome, <?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?></h1>
            <p>Role: <?php echo htmlspecialchars($role); ?></p>
            <div class="dashboard-actions">
                <?php foreach ($links as $link): ?>
                    <a class="dashboard-link" href="<?php echo htmlspecialchars($link['href']); ?>"><?php echo htmlspecialchars($link['title']); ?></a>
                <?php endforeach; ?>
                <a class="logout-button" href="logout.php">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>
