<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

$pdo = get_db_connection();
$dueWindow = new DateTime('+2 days');

$stmt = $pdo->prepare('SELECT bt.*, u.id AS user_id, u.full_name, u.email, b.title FROM borrow_transactions bt JOIN users u ON bt.user_id = u.id JOIN books b ON bt.book_id = b.id WHERE bt.returned_at IS NULL AND bt.due_date BETWEEN NOW() AND :due_window');
$stmt->execute([':due_window' => $dueWindow->format('Y-m-d H:i:s')]);
$dueSoon = $stmt->fetchAll();

$stmt = $pdo->query('SELECT bt.*, u.id AS user_id, u.full_name, u.email, b.title FROM borrow_transactions bt JOIN users u ON bt.user_id = u.id JOIN books b ON bt.book_id = b.id WHERE bt.returned_at IS NULL AND bt.due_date < NOW()');
$overdue = $stmt->fetchAll();

$sentDue = 0;
$sentOverdue = 0;

foreach ($dueSoon as $record) {
    $subject = 'CUOM Library Due Reminder';
    $messageText = sprintf(
        'Hello %s,<br><br>Your borrowed book "%s" is due on %s.<br>Please return it on time to avoid fines.<br><br>CUOM Library',
        htmlspecialchars($record['full_name']),
        htmlspecialchars($record['title']),
        htmlspecialchars($record['due_date'])
    );
    if (send_user_notification($record['user_id'], 'due_reminder', $subject, $messageText)) {
        $sentDue++;
    }
}

foreach ($overdue as $record) {
    $subject = 'CUOM Library Overdue Notice';
    $messageText = sprintf(
        'Hello %s,<br><br>Your borrowed book "%s" is overdue since %s.<br>Please return it immediately and settle any fines.<br><br>CUOM Library',
        htmlspecialchars($record['full_name']),
        htmlspecialchars($record['title']),
        htmlspecialchars($record['due_date'])
    );
    if (send_user_notification($record['user_id'], 'overdue_notice', $subject, $messageText)) {
        $sentOverdue++;
    }
}

echo "Reminders sent: Due Soon={$sentDue}, Overdue={$sentOverdue}.\n";
