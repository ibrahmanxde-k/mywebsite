<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

require_role(['Administrator', 'Librarian']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: member_requests.php');
    exit;
}

if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    set_flash('Invalid request token.', 'error');
    redirect_to('member_requests.php');
}

$userId = (int) ($_POST['user_id'] ?? 0);
$action = $_POST['action'] ?? '';

if ($userId <= 0 || !in_array($action, ['approve', 'reject'], true)) {
    set_flash('Invalid action.', 'error');
    redirect_to('member_requests.php');
}

$pdo = get_db_connection();
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    set_flash('Member not found.', 'error');
    redirect_to('member_requests.php');
}

if ($action === 'approve') {
    $stmt = $pdo->prepare('UPDATE users SET status = 1 WHERE id = :id');
    $stmt->execute([':id' => $userId]);
    $subject = 'CUOM Library Registration Approved';
    $message = 'Hello ' . htmlspecialchars($user['full_name']) . ",<br><br>Your registration has been approved. You may now log in with your Institution ID and password.<br><br>– CUOM Library";
    send_user_notification($userId, 'member_approved', $subject, $message);
    set_flash('Member approved and notified successfully.');
} else {
    $stmt = $pdo->prepare('DELETE FROM users WHERE id = :id');
    $stmt->execute([':id' => $userId]);
    set_flash('Member registration request rejected and removed.');
}

redirect_to('member_requests.php');
