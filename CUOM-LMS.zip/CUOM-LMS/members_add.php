<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

require_role(['Administrator', 'Librarian']);
$branches = get_active_branches();
$memberRoleId = get_role_id_by_name('Member');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        redirect_to('members_add.php');
    }

    $institution_id = trim($_POST['institution_id'] ?? '');
    $registration_number = trim($_POST['registration_number'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $branch_id = $_POST['branch_id'] ?? null;

    if ($institution_id === '' || $full_name === '' || $email === '') {
        set_flash('Institution ID, name, and email are required.', 'error');
        redirect_to('members_add.php');
    }

    $password = password_hash('Member@123', PASSWORD_DEFAULT);

    $pdo = get_db_connection();
    $stmt = $pdo->prepare('INSERT INTO users (institution_id, registration_number, email, password_hash, role_id, branch_id, full_name, status) VALUES (:institution_id, :registration_number, :email, :password_hash, :role_id, :branch_id, :full_name, 1)');
    $stmt->execute([
        ':institution_id' => $institution_id,
        ':registration_number' => $registration_number,
        ':email' => $email,
        ':password_hash' => $password,
        ':role_id' => $memberRoleId,
        ':branch_id' => $branch_id ?: null,
        ':full_name' => $full_name,
    ]);

    set_flash('Member created successfully. Default password is Member@123.');
    redirect_to('members.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Member - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Register Member</h1>
            <?php render_flash_messages(); ?>
            <form method="post" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <label for="institution_id">Institution ID</label>
                <input type="text" id="institution_id" name="institution_id" value="<?php echo old_value('institution_id'); ?>" required>

                <label for="registration_number">Registration Number</label>
                <input type="text" id="registration_number" name="registration_number" value="<?php echo old_value('registration_number'); ?>">

                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" value="<?php echo old_value('full_name'); ?>" required>

                <label for="email">Email</label>
                <input type="text" id="email" name="email" value="<?php echo old_value('email'); ?>" required>

                <label for="branch_id">Preferred Branch</label>
                <select id="branch_id" name="branch_id">
                    <option value="">Unassigned</option>
                    <?php foreach ($branches as $branch): ?>
                        <option value="<?php echo $branch['id']; ?>"><?php echo htmlspecialchars($branch['name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <button type="submit">Create Member</button>
            </form>
            <p><a href="members.php">Back to member list</a></p>
        </div>
    </div>
</body>
</html>
