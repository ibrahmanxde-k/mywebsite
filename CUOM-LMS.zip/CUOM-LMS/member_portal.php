<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_role('Member');

$user = get_current_user();
$borrowings = get_user_due_borrowings($user['id']);
$notifications = get_notifications_for_user($user['id'], 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Portal - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Member Portal</h1>
            <p>Welcome back, <?php echo htmlspecialchars($user['full_name']); ?>. Review your active loans, due dates, and recent notifications.</p>
            <section class="notification-panel">
                <h2>Recent Notifications</h2>
                <?php if (empty($notifications)): ?>
                    <p>No notifications yet.</p>
                <?php else: ?>
                    <ul>
                        <?php foreach ($notifications as $note): ?>
                            <li>
                                <strong><?php echo htmlspecialchars($note['subject']); ?></strong>
                                <div><?php echo htmlspecialchars($note['message']); ?></div>
                                <small><?php echo htmlspecialchars($note['created_at']); ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
            <section class="borrowings-panel">
                <h2>Active Borrowings</h2>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Borrowed</th>
                            <th>Due</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($borrowings)): ?>
                            <tr>
                                <td colspan="4">No active borrowings.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($borrowings as $borrow): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($borrow['title']); ?></td>
                                    <td><?php echo htmlspecialchars($borrow['borrowed_at']); ?></td>
                                    <td><?php echo htmlspecialchars($borrow['due_date']); ?></td>
                                    <td><?php echo htmlspecialchars($borrow['status']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
