<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

require_role(['Administrator', 'Librarian']);
$pdo = get_db_connection();
$stmt = $pdo->query('SELECT bt.*, b.title AS book_title, u.full_name AS member_name, br.name AS branch_name FROM borrow_transactions bt JOIN books b ON bt.book_id = b.id JOIN users u ON bt.user_id = u.id JOIN branches br ON bt.branch_id = br.id WHERE bt.returned_at IS NULL ORDER BY bt.due_date ASC');
$transactions = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        header('Location: return_book.php');
        exit;
    }

    $transactionId = (int) ($_POST['transaction_id'] ?? 0);
    if (!$transactionId) {
        set_flash('Please select a transaction to return.', 'error');
        header('Location: return_book.php');
        exit;
    }

    $stmt = $pdo->prepare('SELECT bt.*, b.title, b.id AS book_id, u.id AS user_id FROM borrow_transactions bt JOIN books b ON bt.book_id = b.id JOIN users u ON bt.user_id = u.id WHERE bt.id = :id LIMIT 1');
    $stmt->execute([':id' => $transactionId]);
    $transaction = $stmt->fetch();

    if (!$transaction) {
        set_flash('Borrow transaction not found.', 'error');
        header('Location: return_book.php');
        exit;
    }

    $returnDate = new DateTime();
    $fineAmount = calculate_fine_amount($transaction['due_date'], $returnDate->format('Y-m-d H:i:s'));
    $status = $fineAmount > 0 ? 'overdue' : 'returned';

    $pdo->beginTransaction();
    $stmt = $pdo->prepare('UPDATE borrow_transactions SET returned_at = :returned_at, status = :status, fine_amount = :fine_amount WHERE id = :id');
    $stmt->execute([
        ':returned_at' => $returnDate->format('Y-m-d H:i:s'),
        ':status' => $status,
        ':fine_amount' => $fineAmount,
        ':id' => $transactionId,
    ]);

    $stmt = $pdo->prepare('UPDATE books SET available_quantity = available_quantity + 1 WHERE id = :book_id');
    $stmt->execute([':book_id' => $transaction['book_id']]);

    if ($fineAmount > 0) {
        $stmt = $pdo->prepare('INSERT INTO fines (transaction_id, amount, paid_amount, status) VALUES (:transaction_id, :amount, 0.00, :status)');
        $stmt->execute([':transaction_id' => $transactionId, ':amount' => $fineAmount, ':status' => 'unpaid']);
    }

    $pdo->commit();
    record_audit_log($_SESSION['user_id'], 'return_book', 'Returned transaction ID ' . $transactionId . ' with fine ' . $fineAmount);

    $subject = 'CUOM Library Return Confirmation';
    $messageText = 'Hello ' . htmlspecialchars($transaction['member_name']) . ',<br><br>Your return for "' . htmlspecialchars($transaction['title']) . '" has been processed.';
    if ($fineAmount > 0) {
        $messageText .= '<br>Your overdue fine is TZS ' . number_format($fineAmount, 2) . '. Please settle this amount at the library.';
    }
    $messageText .= '<br><br>CUOM Library';
    send_user_notification($transaction['user_id'], 'return_confirmation', $subject, $messageText);

    set_flash('Return processed successfully.');
    header('Location: return_book.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Book - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Return Book</h1>
            <?php render_flash_messages(); ?>
            <form method="post" action="return_book.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <label for="transaction_id">Active Borrowing</label>
                <select id="transaction_id" name="transaction_id" required>
                    <option value="">Select transaction</option>
                    <?php foreach ($transactions as $txn): ?>
                        <option value="<?php echo $txn['id']; ?>">
                            <?php echo htmlspecialchars($txn['book_title'] . ' borrowed by ' . $txn['member_name'] . ' due ' . $txn['due_date'] . ' (' . $txn['status'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Process Return</button>
            </form>
            <p><a href="borrowings.php">Back to transactions</a></p>
        </div>
    </div>
</body>
</html>
