<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

require_role(['Administrator', 'Librarian']);

$pdo = get_db_connection();
$dueSoon = [];
$overdue = [];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
    } else {
        $now = new DateTime();
        $dueWindow = new DateTime('+2 days');

        $stmt = $pdo->prepare('SELECT bt.*, u.id AS user_id, u.full_name, u.email, b.title FROM borrow_transactions bt JOIN users u ON bt.user_id = u.id JOIN books b ON bt.book_id = b.id WHERE bt.returned_at IS NULL AND bt.due_date BETWEEN NOW() AND :due_window');
        $stmt->execute([':due_window' => $dueWindow->format('Y-m-d H:i:s')]);
        $dueSoon = $stmt->fetchAll();

        $stmt = $pdo->query('SELECT bt.*, u.id AS user_id, u.full_name, u.email, b.title FROM borrow_transactions bt JOIN users u ON bt.user_id = u.id JOIN books b ON bt.book_id = b.id WHERE bt.returned_at IS NULL AND bt.due_date < NOW()');
        $overdue = $stmt->fetchAll();

        foreach ($dueSoon as $record) {
            $subject = 'CUOM Library Due Reminder';
            $messageText = sprintf(
                'Hello %s,<br><br>Your borrowed book "%s" is due on %s.<br>Please return it on time to avoid fines.<br><br>CUOM Library',
                htmlspecialchars($record['full_name']),
                htmlspecialchars($record['title']),
                htmlspecialchars($record['due_date'])
            );
            send_user_notification($record['user_id'], 'due_reminder', $subject, $messageText);
        }

        foreach ($overdue as $record) {
            $subject = 'CUOM Library Overdue Notice';
            $messageText = sprintf(
                'Hello %s,<br><br>Your borrowed book "%s" is overdue since %s.<br>Please return it immediately and settle any fines.<br><br>CUOM Library',
                htmlspecialchars($record['full_name']),
                htmlspecialchars($record['title']),
                htmlspecialchars($record['due_date'])
            );
            send_user_notification($record['user_id'], 'overdue_notice', $subject, $messageText);
        }

        set_flash('Due reminders and overdue notices were sent to applicable members.', 'success');
    }
}

$stmt = $pdo->query('SELECT COUNT(*) FROM borrow_transactions WHERE returned_at IS NULL AND due_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 2 DAY)');
$dueSoonCount = $stmt->fetchColumn();
$stmt = $pdo->query('SELECT COUNT(*) FROM borrow_transactions WHERE returned_at IS NULL AND due_date < NOW()');
$overdueCount = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Reminders - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Reminder Notifications</h1>
            <p>Send due-date and overdue book reminders to members.</p>
            <?php render_flash_messages(); ?>
            <p>Borrowings due in next 2 days: <strong><?php echo (int) $dueSoonCount; ?></strong></p>
            <p>Overdue borrowings: <strong><?php echo (int) $overdueCount; ?></strong></p>
            <form method="post" action="send_reminders.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <button type="submit">Send Reminders Now</button>
            </form>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
