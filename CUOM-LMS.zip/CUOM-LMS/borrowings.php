<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_role(['Administrator', 'Librarian']);

$pdo = get_db_connection();
$stmt = $pdo->query('SELECT bt.*, b.title AS book_title, u.full_name AS member_name, br.name AS branch_name FROM borrow_transactions bt JOIN books b ON bt.book_id = b.id JOIN users u ON bt.user_id = u.id JOIN branches br ON bt.branch_id = br.id ORDER BY bt.borrowed_at DESC');
$transactions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrowing Transactions - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Borrowing & Return Records</h1>
            <p>Track borrowed items, due dates, and transaction status.</p>
            <div class="dashboard-actions">
                <a class="dashboard-link" href="borrow_book.php">Borrow Book</a>
                <a class="dashboard-link" href="return_book.php">Return Book</a>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Book</th>
                        <th>Member</th>
                        <th>Branch</th>
                        <th>Borrowed</th>
                        <th>Due</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $txn): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($txn['book_title']); ?></td>
                            <td><?php echo htmlspecialchars($txn['member_name']); ?></td>
                            <td><?php echo htmlspecialchars($txn['branch_name']); ?></td>
                            <td><?php echo htmlspecialchars($txn['borrowed_at']); ?></td>
                            <td><?php echo htmlspecialchars($txn['due_date']); ?></td>
                            <td><?php echo htmlspecialchars($txn['status']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
