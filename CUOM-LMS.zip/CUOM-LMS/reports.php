<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

require_role(['Administrator', 'Librarian']);
$pdo = get_db_connection();

$counts = [];
$counts['total_books'] = $pdo->query('SELECT COUNT(*) FROM books')->fetchColumn();
$counts['available_books'] = $pdo->query('SELECT SUM(available_quantity) FROM books')->fetchColumn();
$counts['total_members'] = $pdo->query('SELECT COUNT(*) FROM users WHERE role_id = (SELECT id FROM roles WHERE name = "Member")')->fetchColumn();
$counts['active_members'] = $pdo->query('SELECT COUNT(*) FROM users WHERE role_id = (SELECT id FROM roles WHERE name = "Member") AND status = 1')->fetchColumn();
$counts['borrowed_items'] = $pdo->query('SELECT COUNT(*) FROM borrow_transactions WHERE returned_at IS NULL')->fetchColumn();
$counts['overdue_items'] = $pdo->query('SELECT COUNT(*) FROM borrow_transactions WHERE returned_at IS NULL AND due_date < NOW()')->fetchColumn();

$categoryStmt = $pdo->query('SELECT c.name, COUNT(b.id) AS total FROM categories c LEFT JOIN books b ON b.category_id = c.id GROUP BY c.id ORDER BY total DESC');
$categoryStats = $categoryStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Reports & Analytics</h1>
            <p>View summary statistics for library inventory and member usage.</p>
            <div class="report-grid">
                <div class="report-card"><strong>Total Books</strong><p><?php echo (int) $counts['total_books']; ?></p></div>
                <div class="report-card"><strong>Available Books</strong><p><?php echo (int) $counts['available_books']; ?></p></div>
                <div class="report-card"><strong>Total Members</strong><p><?php echo (int) $counts['total_members']; ?></p></div>
                <div class="report-card"><strong>Active Members</strong><p><?php echo (int) $counts['active_members']; ?></p></div>
                <div class="report-card"><strong>Borrowed Items</strong><p><?php echo (int) $counts['borrowed_items']; ?></p></div>
                <div class="report-card"><strong>Overdue Items</strong><p><?php echo (int) $counts['overdue_items']; ?></p></div>
            </div>
            <canvas id="categoryChart" width="400" height="250"></canvas>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const labels = <?php echo json_encode(array_column($categoryStats, 'name')); ?>;
        const values = <?php echo json_encode(array_column($categoryStats, 'total')); ?>;
        const ctx = document.getElementById('categoryChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Books by Category',
                    data: values,
                    backgroundColor: 'rgba(59, 130, 246, 0.7)',
                    borderColor: 'rgba(37, 99, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
