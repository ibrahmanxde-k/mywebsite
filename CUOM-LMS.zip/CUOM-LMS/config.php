<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'cuom_lms');
define('DB_USER', 'root');
define('DB_PASS', '');

define('APP_NAME', 'CUOM Library Management System');
define('SESSION_TIMEOUT', 1800); // 30 minutes
define('PASSWORD_RESET_TOKEN_EXPIRY', 1800); // 30 minutes
define('FAILED_LOGIN_LIMIT', 5);
define('FAILED_LOGIN_WINDOW', 900); // 15 minutes

global $sessionStarted;
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function secure_session_start() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } elseif (time() - $_SESSION['created'] > SESSION_TIMEOUT) {
        session_regenerate_id(true);
        $_SESSION = [];
        session_destroy();
        session_start();
    }
}

secure_session_start();
