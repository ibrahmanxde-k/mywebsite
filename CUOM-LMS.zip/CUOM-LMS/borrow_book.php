<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/notifications.php';

require_role(['Administrator', 'Librarian']);
$members = get_active_members();
$books = get_available_books();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('Invalid request token.', 'error');
        header('Location: borrow_book.php');
        exit;
    }

    $memberId = (int) ($_POST['member_id'] ?? 0);
    $bookId = (int) ($_POST['book_id'] ?? 0);
    $days = max(1, (int) ($_POST['loan_days'] ?? 14));

    if (!$memberId || !$bookId) {
        set_flash('Please select a member and a book.', 'error');
        header('Location: borrow_book.php');
        exit;
    }

    $pdo = get_db_connection();
    $stmt = $pdo->prepare('SELECT available_quantity, branch_id, title FROM books WHERE id = :id AND status = 1 LIMIT 1');
    $stmt->execute([':id' => $bookId]);
    $book = $stmt->fetch();

    if (!$book || $book['available_quantity'] < 1) {
        set_flash('Selected book is not available.', 'error');
        header('Location: borrow_book.php');
        exit;
    }

    $borrowedAt = new DateTime();
    $dueDate = (clone $borrowedAt)->modify("+{$days} days");

    $stmt = $pdo->prepare('INSERT INTO borrow_transactions (book_id, user_id, branch_id, borrowed_at, due_date, status) VALUES (:book_id, :user_id, :branch_id, :borrowed_at, :due_date, :status)');
    $stmt->execute([
        ':book_id' => $bookId,
        ':user_id' => $memberId,
        ':branch_id' => $book['branch_id'] ?? 1,
        ':borrowed_at' => $borrowedAt->format('Y-m-d H:i:s'),
        ':due_date' => $dueDate->format('Y-m-d H:i:s'),
        ':status' => 'borrowed',
    ]);

    $stmt = $pdo->prepare('UPDATE books SET available_quantity = available_quantity - 1 WHERE id = :id');
    $stmt->execute([':id' => $bookId]);

    record_audit_log($_SESSION['user_id'], 'borrow_book', 'Member ID ' . $memberId . ' borrowed book ID ' . $bookId);
    send_user_notification($memberId, 'borrow_notice', 'Book Borrowed', 'You have borrowed "' . htmlspecialchars($book['title']) . '" due on ' . $dueDate->format('Y-m-d') . '.');

    set_flash('Borrow transaction created successfully.');
    header('Location: borrowings.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Book - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Borrow Book</h1>
            <?php render_flash_messages(); ?>
            <form method="post" action="borrow_book.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(get_csrf_token()); ?>">
                <label for="member_id">Member</label>
                <select id="member_id" name="member_id" required>
                    <option value="">Select member</option>
                    <?php foreach ($members as $member): ?>
                        <option value="<?php echo $member['id']; ?>"><?php echo htmlspecialchars($member['full_name'] . ' (' . $member['institution_id'] . ')'); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="book_id">Book</label>
                <select id="book_id" name="book_id" required>
                    <option value="">Select available book</option>
                    <?php foreach ($books as $book): ?>
                        <option value="<?php echo $book['id']; ?>"><?php echo htmlspecialchars($book['title'] . ' - ' . $book['branch_name'] . ' (' . $book['available_quantity'] . ' available)'); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="loan_days">Loan Period (days)</label>
                <input type="number" id="loan_days" name="loan_days" min="1" value="14" required>

                <button type="submit">Create Borrowing</button>
            </form>
            <p><a href="borrowings.php">Back to transactions</a></p>
        </div>
    </div>
</body>
</html>
