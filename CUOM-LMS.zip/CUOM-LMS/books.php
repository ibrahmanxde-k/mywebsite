<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_role(['Administrator', 'Librarian']);

$pdo = get_db_connection();
$stmt = $pdo->query('SELECT b.*, c.name AS category_name, br.name AS branch_name FROM books b LEFT JOIN categories c ON b.category_id = c.id LEFT JOIN branches br ON b.branch_id = br.id ORDER BY b.title');
$books = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books - CUOM LMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="login-card">
            <h1>Books Inventory</h1>
            <p>Manage books, categories, and branch allocation.</p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Branch</th>
                        <th>Available</th>
                        <th>Total</th>
                        <th>QR Label</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $book): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($book['title']); ?></td>
                            <td><?php echo htmlspecialchars($book['author']); ?></td>
                            <td><?php echo htmlspecialchars($book['category_name'] ?? 'General'); ?></td>
                            <td><?php echo htmlspecialchars($book['branch_name'] ?? 'Unassigned'); ?></td>
                            <td><?php echo (int) $book['available_quantity']; ?></td>
                            <td><?php echo (int) $book['total_quantity']; ?></td>
                            <td>
                                <?php if (!empty($book['qr_code'])): ?>
                                    <img src="https://chart.googleapis.com/chart?chs=120x120&cht=qr&chl=<?php echo urlencode($book['qr_code']); ?>&choe=UTF-8" alt="QR Code" width="80" height="80">
                                    <div><?php echo htmlspecialchars($book['qr_code']); ?></div>
                                <?php else: ?>
                                    <span>N/A</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p><a href="dashboard.php">Back to dashboard</a></p>
        </div>
    </div>
</body>
</html>
